import { useState } from 'react';
import React from 'react';
import { data } from './data';
import StudentList from './studentList';

export default function Students() {
    const [students, setStudents] = useState(data);
    const [errorMessage, setMeassge] = useState('')
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [emailId, setEmailId] = useState('');
    const [flag, setFlag] = useState(false);
    const [updatedIndex, setUpdateIndex] = useState(0);
    // const [cancelIndex, setCancelIndex] = useState(0);

    const deleteHandler = (index) => {
        // console.log('index',index);
        let newStudents = students.filter((student, i) => {
            if (i !== index) {
                return student;
            }
        });
        setStudents([...newStudents]);
    }

    const updateHandler = (student, index) => {
        console.log("need to update", student);
        setUpdateIndex(index);
        setFirstName(student.firstName);
        setLastName(student.lastName);
        setEmailId(student.emailId);
        setFlag(true);
    }



    const ctaHandler = () => {
        setMeassge('');

        if (!firstName || !lastName || !emailId) {
            setMeassge('input field are required');
            return;
        }
        let student = {
            firstName,
            lastName,
            emailId
        }
        // console.log("students",student)
        setStudents([student, ...students]);
        setFirstName('');
        setLastName('');
        setEmailId('');
    }
    const ctaUpdateHandler = () => {
        setMeassge('');

        if (!firstName || !lastName || !emailId) {
            setMeassge('input field are required');
            return;
        }
        let student = {
            firstName,
            lastName,
            emailId
        }
        let updateStudent = students.map((stu, index) => {
            if (updatedIndex === index) {
                return student;
            }
            else {
                return stu;
            }
        })
        // console.log("students",student)
        setStudents([...updateStudent]);
        setFirstName('');
        setLastName('');
        setEmailId('');
        setFlag(false);
    }

    // cta cancel handler 

   
    


    return (
        <div>
            <h1 style={{ textAlign: 'center' }}>Add New Students</h1>
            <div className='conatiner'>
                <div className='row'>
                    <div className='col-md-8 mx-auto'>
                        <input type='text' className='form-control' name='name' value={firstName} placeholder='Enter the Firs Name' onChange={(e) => setFirstName(e.target.value)} /><br /><br />
                        <input type='text' className='form-control' value={lastName} placeholder='Enter the Last Name' onChange={(e) => setLastName(e.target.value)} /><br /><br />
                        <input type='email' className='form-control' value={emailId} placeholder='Enter your Email' onChange={(e) => setEmailId(e.target.value)} /><br /><br />
                        {flag ?
                            <button type='submit' className='btn btn-outline-warning btn-lg btn-block' onClick={ctaUpdateHandler}>update</button>
                            :
                            <button type='submit' className='btn btn-outline-primary btn-lg btn-block' onClick={ctaHandler}>Submit</button>
                        }
            
                        
                        <p style={{ backgroundColor: 'red', color: 'white', width: '10%', textAlign: 'center', borderRadius: '10px', margin: '10px' }}>
                            {
                                errorMessage
                            }
                        </p>
                        <hr />
                    </div>
                </div>
            </div>


            <h2 style={{ textAlign: 'center' }}>List of students</h2>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-9 mx-auto'>
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th scope='col'>No.</th>
                                    <th scope="col">Employee First Name</th>
                                    <th scope="col">Employee Last Name</th>
                                    <th scope="col">Employee E-mail Id</th>
                                    <th scope='col'>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    students.map((item, index) => {
                                        return <StudentList index={index} student={item} deleteHandler={deleteHandler} updateHandler={updateHandler}  />
                                    }
                                    )
                                }


                            </tbody>
                        </table>

                    </div>
                </div>
            </div>

        </div>
    )
}







// const inputHandler=(e)=>{
    //     console.log('e',e.target.name);
    //     console.log('E',e.target.value);
    // }